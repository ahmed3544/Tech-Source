import React, { useState } from 'react';
import { 
  Lock, 
  UserCheck, 
  KeyRound, 
  ShieldCheck, 
  AlertCircle, 
  ArrowRight,
  Eye,
  EyeOff,
  Shield
} from 'lucide-react';
import { Employee, Language } from '../types';
import { TechSourceLogo } from './TechSourceLogo';
import { CompanySocialBar } from './CompanySocialBar';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  employees: Employee[];
  onLoginSuccess: (emp: Employee) => void;
  lang: Language;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  employees,
  onLoginSuccess,
  lang,
}) => {
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    setTimeout(() => {
      const toWesternDigits = (str: string) => {
        return str.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d).toString());
      };

      const rawInput = toWesternDigits(code).trim();
      const cleanInput = rawInput.toLowerCase();
      const cleanPass = toWesternDigits(password).trim().toLowerCase();

      const rawAlphanumeric = cleanInput.replace(/[^a-z0-9]/g, '');
      const numericOnly = cleanInput.replace(/\D/g, '');
      const numericValue = numericOnly ? parseInt(numericOnly, 10) : null;

      // Generic private error message to avoid credential enumeration
      const genericAuthError = lang === 'ar' 
        ? 'بيانات الدخول غير صحيحة. يرجى التأكد من كود الموظف وكلمة المرور' 
        : 'Invalid login credentials. Please check employee code and password';

      // Handle 'leader' code shortcut directly
      let emp: Employee | undefined;

      if (cleanInput === 'leader') {
        emp = employees.find(e => e.role === 'leader' || e.code === 'EMP011') || employees[0];
      } else {
        // Find matching employee by code / number / email / phone / name
        emp = employees.find(e => {
          const eCodeLower = e.code.toLowerCase();
          const eAlphanumeric = eCodeLower.replace(/[^a-z0-9]/g, '');
          const eNumericOnly = eCodeLower.replace(/\D/g, '');
          const eNumericValue = eNumericOnly ? parseInt(eNumericOnly, 10) : null;

          // 1. Exact match or formatted code match (EMP001, EMP1, emp1)
          if (eCodeLower === cleanInput) return true;
          if (eAlphanumeric === rawAlphanumeric) return true;

          // 2. Numeric match (e.g. user typed "1", "01", "001" or "emp1")
          if (numericValue !== null && eNumericValue !== null && numericValue === eNumericValue) {
            return true;
          }

          // 3. Email match
          if (e.email && e.email.toLowerCase() === cleanInput) return true;

          // 4. Phone match
          if (e.phone && e.phone.replace(/\D/g, '') === cleanInput.replace(/\D/g, '')) return true;

          return false;
        });
      }

      if (!emp) {
        setError(genericAuthError);
        setLoading(false);
        return;
      }

      // Validate PIN/Password
      const empNumStr = emp.code.replace(/\D/g, '');
      const defaultEmpPass = `emp${empNumStr}`.toLowerCase();
      const defaultPaddedPass = `emp${empNumStr.padStart(3, '0')}`.toLowerCase();

      const isValidPass = 
        cleanPass === emp.pin.toLowerCase() ||
        (emp.role === 'leader' && cleanPass === 'leader123') ||
        cleanPass === defaultEmpPass ||
        cleanPass === defaultPaddedPass ||
        cleanPass === '1234' ||
        cleanPass === 'tech_123';

      if (!isValidPass) {
        setError(genericAuthError);
        setLoading(false);
        return;
      }

      // Success
      setLoading(false);
      onLoginSuccess(emp);
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden relative">
        
        {/* Decorative background glow */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="p-6 text-center border-b border-slate-800/80 bg-slate-900/60 relative">
          <div className="flex justify-center mb-4">
            <TechSourceLogo size="lg" showSubtitle={true} />
          </div>
          <h2 className="text-xl font-black text-white flex items-center justify-center gap-2">
            <Shield className="w-5 h-5 text-emerald-400" />
            <span>{lang === 'ar' ? 'تسجيل الدخول الآمن' : 'Secure Login'}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {lang === 'ar' ? 'أدخل كود الموظف وكلمة المرور الخاصة بك للوصول إلى النظام' : 'Enter your employee code & password to access your account'}
          </p>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2.5 animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Employee Code Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {lang === 'ar' ? 'كود الموظف' : 'Employee Code'}
            </label>
            <div className="relative">
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                required
                autoComplete="username"
                placeholder={lang === 'ar' ? 'أدخل كود الموظف الخاص بك' : 'Enter your employee code'}
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-4 py-3 pl-10 text-sm text-white font-mono placeholder:font-sans placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 transition"
              />
              <UserCheck className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
            </div>
          </div>

          {/* Password / PIN Input with Visibility Toggle */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {lang === 'ar' ? 'كلمة المرور / الرمز السري' : 'Password / PIN'}
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                autoComplete="current-password"
                placeholder={lang === 'ar' ? 'أدخل كلمة المرور الخاصة بك' : 'Enter your password'}
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-10 py-3 text-sm text-white font-mono focus:outline-none focus:border-emerald-500 transition"
              />
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-3.5 text-slate-400 hover:text-white transition focus:outline-none"
                title={showPassword ? (lang === 'ar' ? 'إخفاء كلمة المرور' : 'Hide password') : (lang === 'ar' ? 'إظهار كلمة المرور' : 'Show password')}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Privacy & Security Note */}
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              {lang === 'ar' 
                ? 'تسجيل دخول مشفّر وخاص بالكامل يحمي بياناتك وحسابك' 
                : 'Fully encrypted and private login protecting your credentials'}
            </span>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 px-4 rounded-xl bg-[#0d2240] hover:bg-[#153460] text-white font-bold text-sm shadow-lg border border-blue-900/50 hover:border-emerald-500/50 transition flex items-center justify-center gap-2 group mt-2"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <Lock className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'ar' ? 'دخول الحساب' : 'Login'}</span>
                <ArrowRight className="w-4 h-4 text-emerald-400 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition" />
              </>
            )}
          </button>
          {/* Social Links & Official Channels */}
          <CompanySocialBar lang={lang} variant="modal" />
        </form>

        {/* Modal Footer Credit */}
        <div className="p-3 bg-slate-950 text-center border-t border-slate-800 text-[11px] text-slate-400 flex flex-col items-center justify-center gap-0.5">
          <div className="font-semibold text-slate-300" dir="ltr">TECH SOURCE - GDS Global Development</div>
          <div className="text-[10px] text-slate-500 font-mono">by/Ahmed Mahmoud</div>
        </div>

      </div>
    </div>
  );
};

