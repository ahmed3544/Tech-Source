import React, { useState } from 'react';
import { 
  Search, 
  FileSpreadsheet, 
  Plus, 
  Edit3, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  X,
  ShieldAlert,
  Coffee,
  RotateCcw
} from 'lucide-react';
import { AttendanceRecord, Employee, Shift, AttendanceStatus, Language } from '../types';
import { UserAvatar } from './UserAvatar';
import { BreakTimer } from './BreakTimer';
import { getStatusBadgeStyle, getStatusText, evaluatePunch, formatTime, formatDate, toWesternDigits, getFirstTwoNames } from '../utils/helpers';

interface AttendanceLogTableProps {
  records: AttendanceRecord[];
  employees: Employee[];
  shifts: Shift[];
  onAddRecord: (record: AttendanceRecord) => void;
  onUpdateRecord: (record: AttendanceRecord) => void;
  onExportCSV: () => void;
  lang: Language;
  onForceEndBreak?: (empId: string) => void;
  currentUser?: Employee | null;
}

export const AttendanceLogTable: React.FC<AttendanceLogTableProps> = ({
  records,
  employees,
  shifts,
  onAddRecord,
  onUpdateRecord,
  onExportCSV,
  lang,
  onForceEndBreak,
  currentUser,
}) => {
  const isLeader = currentUser?.code === 'leader' || currentUser?.role === 'leader';

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedDate, setSelectedDate] = useState<string>('');
  
  // Modal State
  const [showModal, setShowModal] = useState(false);
  const [editingRecord, setEditingRecord] = useState<AttendanceRecord | null>(null);

  // Form State
  const [formEmpId, setFormEmpId] = useState(employees[0]?.id || '');
  const [formDate, setFormDate] = useState(new Date().toISOString().split('T')[0]);
  const [formCheckIn, setFormCheckIn] = useState('09:00');
  const [formCheckOut, setFormCheckOut] = useState('17:00');
  const [formNotes, setFormNotes] = useState('');

  const openCreateModal = () => {
    if (!isLeader) return;
    setEditingRecord(null);
    setFormEmpId(employees[0]?.id || '');
    setFormDate(new Date().toISOString().split('T')[0]);
    setFormCheckIn('09:00');
    setFormCheckOut('17:00');
    setFormNotes('');
    setShowModal(true);
  };

  const openEditModal = (rec: AttendanceRecord) => {
    if (!isLeader) return;
    setEditingRecord(rec);
    setFormEmpId(rec.employeeId);
    setFormDate(rec.date);
    setFormCheckIn(rec.checkIn ? rec.checkIn.substring(0, 5) : '09:00');
    setFormCheckOut(rec.checkOut ? rec.checkOut.substring(0, 5) : '17:00');
    setFormNotes(rec.notes || '');
    setShowModal(true);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isLeader) return;
    const emp = employees.find(e => e.id === formEmpId);
    if (!emp) return;

    const shift = shifts.find(s => s.id === emp.shiftId) || shifts[0];
    const evaluated = evaluatePunch(formCheckIn + ':00', formCheckOut ? formCheckOut + ':00' : undefined, shift);

    const recordData: AttendanceRecord = {
      id: editingRecord ? editingRecord.id : `rec-${Date.now()}`,
      employeeId: formEmpId,
      date: formDate,
      checkIn: formCheckIn ? `${formCheckIn}:00` : undefined,
      checkOut: formCheckOut ? `${formCheckOut}:00` : undefined,
      location: '',
      notes: formNotes,
      lateMinutes: evaluated.lateMinutes,
      lateSeconds: evaluated.lateSeconds,
      earlyLeaveMinutes: evaluated.earlyLeaveMinutes,
      workHours: evaluated.workHours,
      overtimeHours: evaluated.overtimeHours,
      status: evaluated.status,
      verifiedByFace: true,
    };

    if (editingRecord) {
      onUpdateRecord(recordData);
    } else {
      onAddRecord(recordData);
    }

    setShowModal(false);
  };

  // Quick Action for Leader: Cancel Accidental Check-Out
  const handleCancelCheckOut = (rec: AttendanceRecord) => {
    if (!isLeader) return;
    const emp = employees.find(e => e.id === rec.employeeId);
    const shift = shifts.find(s => s.id === emp?.shiftId) || shifts[0];

    const evaluated = evaluatePunch(rec.checkIn || '09:00:00', undefined, shift);

    const updatedRecord: AttendanceRecord = {
      ...rec,
      checkOut: undefined,
      workHours: 0,
      earlyLeaveMinutes: 0,
      status: evaluated.status, // Restores status to 'in_progress', 'late', or 'on_time'
      notes: rec.notes 
        ? `${rec.notes} | إلغاء الانصراف الخاطئ بواسطة التيم ليدر` 
        : 'إلغاء الانصراف الخاطئ بواسطة التيم ليدر',
    };

    onUpdateRecord(updatedRecord);
  };

  // Filtering & Sorting Logic
  const filteredRecords = records.filter((rec) => {
    const emp = employees.find(e => e.id === rec.employeeId);
    if (!emp) return false;

    const matchesSearch = 
      emp.nameAr.includes(searchTerm) || 
      emp.nameEn.toLowerCase().includes(searchTerm.toLowerCase()) || 
      emp.code.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesDept = selectedDept === 'all' || emp.department === selectedDept;
    const matchesStatus = selectedStatus === 'all' || rec.status === selectedStatus;
    const matchesDate = !selectedDate || rec.date === selectedDate;

    return matchesSearch && matchesDept && matchesStatus && matchesDate;
  }).sort((a, b) => {
    // Sort by date descending
    if (a.date !== b.date) {
      return b.date.localeCompare(a.date);
    }

    const getRank = (rec: AttendanceRecord) => {
      if (rec.checkIn) return 1;
      if (rec.status === 'on_leave') return 2;
      return 3;
    };

    const rankA = getRank(a);
    const rankB = getRank(b);

    if (rankA !== rankB) return rankA - rankB;

    if (a.checkIn && b.checkIn) {
      return a.checkIn.localeCompare(b.checkIn);
    }

    return 0;
  });

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6 animate-fade-in">
      {/* Header & Control Bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
        <div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5 flex-wrap">
            <span>{lang === 'ar' ? 'سجل الحضور اليومي والورديات' : 'Attendance & Shift Log'}</span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0d2240] text-white text-xs font-bold border border-blue-900 shadow-sm shrink-0" dir="ltr">
              <img src="/logo.png" alt="Tech Source" className="w-4 h-4 object-contain bg-white rounded-full p-0.5" onError={(e) => { (e.currentTarget as HTMLElement).style.display = 'none'; }} />
              <span>TECH SOURCE GDS</span>
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {lang === 'ar' ? 'عرض السجلات اليومية، احتساب التوقيتات بصيغة 12 ساعة، والتسجيل اليدوي لليدر' : 'Manage attendance logs, 12H formats & leader manual entry'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {isLeader && (
            <button
              onClick={openCreateModal}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0d2240] hover:bg-[#153460] text-white font-bold text-xs shadow transition border border-blue-900"
            >
              <Plus className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'ar' ? 'تسجيل حضور يدوي' : 'Add Manual Record'}</span>
            </button>
          )}

          <button
            onClick={onExportCSV}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow transition"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'ar' ? 'تصدير تقرير (CSV)' : 'Export CSV Report'}</span>
          </button>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={lang === 'ar' ? 'بحث باسم الموظف أو الكود (EMP001)...' : 'Search employee...'}
            className="w-full text-xs pr-9 pl-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
          />
        </div>

        {/* Department Filter */}
        <div>
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium font-sans"
          >
            <option value="all">{lang === 'ar' ? 'جميع الأقسام' : 'All Departments'}</option>
            <option value="Innovation">Innovation</option>
            <option value="CX">CX</option>
            <option value="E-Commerce">E-Commerce</option>
            <option value="Quality">Quality</option>
          </select>
        </div>

        {/* Status Filter */}
        <div>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium font-sans"
          >
            <option value="all">{lang === 'ar' ? 'جميع الحالات' : 'All Statuses'}</option>
            <option value="on_time">حاضر (في الوقت)</option>
            <option value="late">متأخر (بعد 09:00 AM)</option>
            <option value="early_leave">انصراف مبكر</option>
            <option value="overtime">ساعات إضافية</option>
            <option value="absent">غائب</option>
            <option value="on_leave">في إجازة</option>
          </select>
        </div>

        {/* Date Filter */}
        <div className="relative">
          <Calendar className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-full text-xs pr-9 pl-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
          />
        </div>
      </div>

      {/* Main Records Table Card */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-[#0d2240] text-white font-bold border-b border-blue-900 whitespace-nowrap">
                <th className="py-4 px-4 whitespace-nowrap">{lang === 'ar' ? 'التاريخ' : 'Date'}</th>
                <th className="py-4 px-4 whitespace-nowrap">{lang === 'ar' ? 'الموظف' : 'Employee'}</th>
                <th className="py-4 px-4 whitespace-nowrap">{lang === 'ar' ? 'القسم' : 'Department'}</th>
                <th className="py-4 px-4 whitespace-nowrap">{lang === 'ar' ? 'وقت الحضور (12H)' : 'Check-In'}</th>
                <th className="py-4 px-4 whitespace-nowrap">{lang === 'ar' ? 'وقت الانصراف (12H)' : 'Check-Out'}</th>
                <th className="py-4 px-4 whitespace-nowrap">{lang === 'ar' ? 'ساعات العمل' : 'Worked Hrs'}</th>
                <th className="py-4 px-4 whitespace-nowrap">{lang === 'ar' ? 'التأخير (بعد 9AM)' : 'Late Time'}</th>
                <th className="py-4 px-4 whitespace-nowrap">{lang === 'ar' ? 'الحالة' : 'Status'}</th>
                {isLeader && <th className="py-4 px-4 text-center whitespace-nowrap">{lang === 'ar' ? 'إجراءات الليدر' : 'Actions'}</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecords.length > 0 ? (
                filteredRecords.map((rec) => {
                  const emp = employees.find(e => e.id === rec.employeeId);
                  if (!emp) return null;
                  const isBreakActive = Boolean(rec.breakStart && !rec.breakEnd);

                  return (
                    <tr key={rec.id} className={`hover:bg-slate-50/80 transition-colors ${isBreakActive ? 'bg-amber-50/40' : ''}`}>
                      <td className="py-3.5 px-4 font-mono font-semibold text-slate-700">{toWesternDigits(rec.date)}</td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <UserAvatar name={emp.nameEn || emp.nameAr} code={emp.code} avatar={emp.avatar} size="sm" />
                          <div>
                            <div className="font-bold text-slate-900 whitespace-nowrap" title={lang === 'ar' ? emp.nameAr : emp.nameEn}>
                              {getFirstTwoNames(lang === 'ar' ? emp.nameAr : emp.nameEn)}
                            </div>
                            <div className="text-[10px] text-slate-500 font-mono font-bold">{emp.code}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 font-medium">{emp.department}</td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        {rec.checkIn ? formatTime(rec.checkIn, lang) : '--:--'}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        {rec.checkOut ? formatTime(rec.checkOut, lang) : '--:--'}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-emerald-700">
                        {rec.workHours ? `${toWesternDigits(rec.workHours)} س` : '-'}
                      </td>
                      <td className="py-3.5 px-4 text-[11px]">
                        {rec.lateMinutes > 0 ? (
                          <span className="text-amber-800 bg-amber-100 px-2 py-0.5 rounded font-bold font-mono inline-block">
                            +{toWesternDigits(rec.lateMinutes)}د {rec.lateSeconds ? `${toWesternDigits(rec.lateSeconds)}ث` : ''}
                          </span>
                        ) : (
                          <span className="text-slate-400 font-mono">-</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex flex-col gap-1">
                          <span className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-bold border ${getStatusBadgeStyle(rec.status)}`}>
                            {getStatusText(rec.status, lang)}
                          </span>
                          {isBreakActive && (
                            <span className="inline-flex items-center gap-1.5 text-[10px] font-bold text-amber-900 bg-amber-200/80 px-2.5 py-1 rounded-full border border-amber-300">
                              <span>في استراحة:</span>
                              <BreakTimer breakStart={rec.breakStart} />
                            </span>
                          )}
                        </div>
                      </td>
                      {isLeader && (
                        <td className="py-3.5 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5 flex-wrap">
                            {rec.checkOut && (
                              <button
                                onClick={() => handleCancelCheckOut(rec)}
                                className="px-2 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-[10px] font-bold shadow transition flex items-center gap-1 shrink-0"
                                title={lang === 'ar' ? 'إلغاء الانصراف الخاطئ وإعادة الموظف كـ (قيد العمل)' : 'Undo Accidental Check-Out'}
                              >
                                <RotateCcw className="w-3 h-3" />
                                <span>{lang === 'ar' ? 'إلغاء انصراف خاطئ' : 'Undo Check-Out'}</span>
                              </button>
                            )}
                            {isBreakActive && onForceEndBreak && (
                              <button
                                onClick={() => onForceEndBreak(emp.id)}
                                className="px-2 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-bold shadow transition flex items-center gap-1"
                                title="إرجاع الموظف من الاستراحة"
                              >
                                <ShieldAlert className="w-3 h-3" />
                                <span>{lang === 'ar' ? 'إرجاع من الاستراحة' : 'Force End Break'}</span>
                              </button>
                            )}
                            <button
                              onClick={() => openEditModal(rec)}
                              className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                              title="تعديل السجل"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={isLeader ? 9 : 8} className="py-12 text-center text-slate-400">
                    <AlertCircle className="w-10 h-10 mx-auto mb-2 opacity-40" />
                    <p className="font-semibold">{lang === 'ar' ? 'لا توجد سجلات تطابق البحث المحدد' : 'No attendance records found'}</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manual Punch Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-lg">
                {editingRecord 
                  ? (lang === 'ar' ? 'تعديل سجل حضور الموظف' : 'Edit Attendance Record') 
                  : (lang === 'ar' ? 'تسجيل حضور يدوي بواسطة التيم ليدر' : 'Leader Manual Punch Record')}
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="space-y-4 text-xs font-sans">
              {/* Select Employee */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">{lang === 'ar' ? 'اختيار الموظف' : 'Select Employee'}</label>
                <select
                  value={formEmpId}
                  onChange={(e) => setFormEmpId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 font-medium"
                  required
                >
                  {employees.map(e => (
                    <option key={e.id} value={e.id}>
                      {e.nameAr} ({e.code}) - {e.department}
                    </option>
                  ))}
                </select>
              </div>

              {/* Date */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">{lang === 'ar' ? 'التاريخ' : 'Date'}</label>
                <input
                  type="date"
                  value={formDate}
                  onChange={(e) => setFormDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 font-mono"
                  required
                />
              </div>

              {/* Check In / Out */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{lang === 'ar' ? 'وقت الدخول (Check-In)' : 'Check-In'}</label>
                  <input
                    type="time"
                    value={formCheckIn}
                    onChange={(e) => setFormCheckIn(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 font-mono"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    {lang === 'ar' ? 'التسجيل بعد 09:00 AM يحسب متأخراً تلقائياً' : 'After 09:00 AM marks late'}
                  </span>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{lang === 'ar' ? 'وقت الخروج (Check-Out)' : 'Check-Out'}</label>
                  <input
                    type="time"
                    value={formCheckOut}
                    onChange={(e) => setFormCheckOut(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 font-mono"
                  />
                  {formCheckOut && (
                    <button
                      type="button"
                      onClick={() => {
                        setFormCheckOut('');
                        setFormNotes(prev => prev ? `${prev} | إلغاء انصراف خاطئ` : 'إلغاء الانصراف الخاطئ بواسطة التيم ليدر');
                      }}
                      className="mt-1.5 text-[11px] font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 bg-amber-50 px-2 py-1 rounded-lg border border-amber-200 transition"
                    >
                      <RotateCcw className="w-3 h-3 text-amber-600" />
                      <span>{lang === 'ar' ? 'مسح وقت الانصراف (إلغاء انصراف خاطئ)' : 'Clear Check-Out (Undo)'}</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">{lang === 'ar' ? 'ملاحظة إدارية' : 'Admin Note'}</label>
                <textarea
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="تسجيل يدوي بواسطة التيم ليدر..."
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5"
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-4 border-t border-slate-100">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const emp = employees.find(e => e.id === formEmpId);
                      if (!emp) return;
                      const recordData: AttendanceRecord = {
                        id: editingRecord ? editingRecord.id : `rec-${Date.now()}`,
                        employeeId: formEmpId,
                        date: formDate,
                        notes: formNotes || `تسجيل غياب عن يوم ${formDate} بواسطة التيم ليدر`,
                        workHours: 0,
                        lateMinutes: 0,
                        earlyLeaveMinutes: 0,
                        overtimeHours: 0,
                        status: 'absent',
                        verifiedByFace: true,
                      };
                      if (editingRecord) {
                        onUpdateRecord(recordData);
                      } else {
                        onAddRecord(recordData);
                      }
                      setShowModal(false);
                    }}
                    className="px-3 py-2 rounded-xl bg-rose-50 text-rose-800 hover:bg-rose-100 font-bold border border-rose-200 text-xs flex items-center gap-1.5"
                  >
                    <ShieldAlert className="w-4 h-4 text-rose-600" />
                    <span>{lang === 'ar' ? 'تسجيل كغياب لليوم' : 'Mark as Absent'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const emp = employees.find(e => e.id === formEmpId);
                      if (!emp) return;
                      const recordData: AttendanceRecord = {
                        id: editingRecord ? editingRecord.id : `rec-${Date.now()}`,
                        employeeId: formEmpId,
                        date: formDate,
                        notes: formNotes || `تم تسجيل اليوم كإجازة معتمدة من قِبل التيم ليدر`,
                        workHours: 0,
                        lateMinutes: 0,
                        earlyLeaveMinutes: 0,
                        overtimeHours: 0,
                        status: 'on_leave',
                        verifiedByFace: true,
                      };
                      if (editingRecord) {
                        onUpdateRecord(recordData);
                      } else {
                        onAddRecord(recordData);
                      }
                      setShowModal(false);
                    }}
                    className="px-3 py-2 rounded-xl bg-sky-50 text-sky-800 hover:bg-sky-100 font-bold border border-sky-200 text-xs flex items-center gap-1.5"
                  >
                    <Coffee className="w-4 h-4 text-sky-600" />
                    <span>{lang === 'ar' ? 'تسجيل كإجازة لليوم' : 'Mark as On Leave'}</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold text-xs"
                  >
                    {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 rounded-xl bg-[#0d2240] hover:bg-[#153460] text-white font-bold shadow text-xs"
                  >
                    {lang === 'ar' ? 'حفظ السجل' : 'Save Record'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
