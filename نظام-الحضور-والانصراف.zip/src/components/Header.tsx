import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  LayoutDashboard, 
  QrCode, 
  Users, 
  CalendarCheck, 
  BarChart3, 
  UserCheck, 
  Globe, 
  Bell, 
  Search,
  Database,
  ShieldCheck,
  User,
  LogOut,
  LogIn,
  Scale,
  Camera
} from 'lucide-react';
import { Employee, Language } from '../types';
import { TechSourceLogo } from './TechSourceLogo';
import { UserAvatar } from './UserAvatar';
import { formatTime, formatDate, getFirstTwoNames } from '../utils/helpers';
import { AvatarModal } from './AvatarModal';

interface HeaderProps {
  activeTab: 'dashboard' | 'kiosk' | 'attendance' | 'employees' | 'leaves' | 'analytics' | 'portal';
  setActiveTab: (tab: 'dashboard' | 'kiosk' | 'attendance' | 'employees' | 'leaves' | 'analytics' | 'portal') => void;
  lang: Language;
  setLang: (lang: Language) => void;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  pendingLeavesCount: number;
  companyNameAr: string;
  companyNameEn: string;
  onOpenImportModal: () => void;
  onOpenRulesModal: () => void;
  currentUser: Employee | null;
  onOpenLoginModal: () => void;
  onLogout: () => void;
  onUpdateEmployee?: (emp: Employee) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  lang,
  setLang,
  searchTerm,
  setSearchTerm,
  pendingLeavesCount,
  companyNameAr,
  companyNameEn,
  onOpenImportModal,
  onOpenRulesModal,
  currentUser,
  onOpenLoginModal,
  onLogout,
  onUpdateEmployee,
}) => {
  const [now, setNow] = useState<Date>(new Date());
  const [showAvatarModal, setShowAvatarModal] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const timeStr = formatTime(now, lang);
  const dateStr = formatDate(now.toISOString(), lang);

  const isLeader = currentUser?.role === 'leader' || !currentUser;

  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
      {/* Top Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 min-h-[72px] py-2 flex items-center justify-between gap-4">
        
        {/* Unified Logo */}
        <div className="flex items-center gap-3">
          <TechSourceLogo size="md" showSubtitle={true} />
        </div>

        {/* Global Search (Leader Only) */}
        {isLeader && (
          <div className="hidden md:flex items-center relative flex-1 max-w-xs">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={lang === 'ar' ? 'بحث عن موظف، كود، قسم...' : 'Search employee, code...'}
              className="w-full bg-slate-800/80 text-slate-100 text-xs pr-9 pl-4 py-2 rounded-lg border border-slate-700/80 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all placeholder:text-slate-500 font-sans"
            />
          </div>
        )}

        {/* Right Section: Real-time Clock, User Status & Control Tools */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Language Switcher (Arabic / English Toggle) */}
          <button
            onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 text-xs font-bold transition shadow-xs"
            title={lang === 'ar' ? 'Switch to English' : 'التحويل للغة العربية'}
          >
            <Globe className="w-4 h-4 text-sky-400" />
            <span className="font-sans text-[11px] font-extrabold uppercase tracking-wide">
              {lang === 'ar' ? 'English' : 'عربي'}
            </span>
          </button>

          {/* Company Official Regulations Modal Button */}
          <button
            onClick={onOpenRulesModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold transition shadow-xs"
            title={lang === 'ar' ? 'عرض لائحة العمل والجزاءات المعتمدة (قانون العمل 2025)' : 'Company Work Regulations'}
          >
            <Scale className="w-3.5 h-3.5 text-amber-400" />
            <span className="whitespace-nowrap">{lang === 'ar' ? 'لائحة الشركة' : 'Company Rules'}</span>
          </button>

          {/* Live Digital Clock (12-Hour Western Digits) */}
          <div className="hidden lg:flex items-center gap-2.5 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700/60">
            <Clock className="w-4 h-4 text-emerald-400 animate-pulse" />
            <div className="text-right">
              <div className="text-xs font-mono font-bold text-white tracking-wider">{timeStr}</div>
              <div className="text-[10px] text-slate-400">{dateStr}</div>
            </div>
          </div>

          {/* User Status / Role Badge */}
          {currentUser ? (
            <div className="flex items-center gap-2 bg-slate-800/90 border border-slate-700/80 rounded-xl px-2.5 py-1">
              {/* Interactive Avatar Button */}
              <button
                type="button"
                onClick={() => setShowAvatarModal(true)}
                className="relative group cursor-pointer"
                title={lang === 'ar' ? 'تغيير صورة البروفايل' : 'Change profile photo'}
              >
                <UserAvatar name={currentUser.nameEn || currentUser.nameAr} code={currentUser.code} avatar={currentUser.avatar} size="xs" />
                <div className="absolute inset-0 rounded-full bg-slate-950/70 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Camera className="w-3 h-3 text-emerald-400" />
                </div>
              </button>

              <div 
                className="hidden sm:block text-right cursor-pointer"
                onClick={() => setShowAvatarModal(true)}
                title={lang === 'ar' ? 'تغيير صورة البروفايل' : 'Change profile photo'}
              >
                <div className="text-xs font-bold text-white whitespace-nowrap" title={lang === 'ar' ? currentUser.nameAr : currentUser.nameEn}>
                  {getFirstTwoNames(lang === 'ar' ? currentUser.nameAr : currentUser.nameEn)}
                </div>
                <div className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1 justify-end">
                  <span>{currentUser.role === 'leader' ? 'TL' : (lang === 'ar' ? 'حساب موظف' : 'Employee Account')}</span>
                  <Camera className="w-2.5 h-2.5 text-slate-400 hover:text-emerald-400" />
                </div>
              </div>

              <button
                onClick={onLogout}
                className="p-1 rounded-md text-slate-400 hover:text-rose-400 hover:bg-slate-700/50 transition mr-1"
                title={lang === 'ar' ? 'تسجيل الخروج' : 'Logout'}
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenLoginModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0d2240] hover:bg-[#153460] text-white border border-blue-900 text-xs font-bold transition shadow-sm"
            >
              <LogIn className="w-3.5 h-3.5 text-emerald-400" />
              <span>{lang === 'ar' ? 'تسجيل الدخول' : 'Login'}</span>
            </button>
          )}

          {/* Notifications (Leader only) */}
          {isLeader && pendingLeavesCount > 0 && (
            <button
              onClick={() => setActiveTab('leaves')}
              className="relative p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              title={`${pendingLeavesCount} طلبات معلقة`}
            >
              <Bell className="w-4 h-4 text-amber-400" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-slate-950 font-bold text-[10px] rounded-full flex items-center justify-center animate-bounce font-mono">
                {pendingLeavesCount}
              </span>
            </button>
          )}

        </div>
      </div>

      {/* Navigation Sub-bar */}
      <nav className="bg-slate-950/80 border-t border-slate-800/80 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex items-center gap-1.5 overflow-x-auto py-1.5 scrollbar-none">
          
          {/* LEADER NAVIGATION TABS */}
          {isLeader ? (
            <>
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activeTab === 'dashboard'
                    ? 'bg-[#0d2240] text-white font-bold border border-blue-900 shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80'
                }`}
              >
                <LayoutDashboard className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'ar' ? 'لوحة التحكم' : 'Dashboard'}</span>
              </button>

              <button
                onClick={() => setActiveTab('kiosk')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activeTab === 'kiosk'
                    ? 'bg-[#0d2240] text-white font-bold border border-blue-900 shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80'
                }`}
              >
                <QrCode className="w-4 h-4 text-teal-400" />
                <span>{lang === 'ar' ? 'تسجيل الحضور' : 'Kiosk Punch'}</span>
              </button>

              <button
                onClick={() => setActiveTab('attendance')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activeTab === 'attendance'
                    ? 'bg-[#0d2240] text-white font-bold border border-blue-900 shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80'
                }`}
              >
                <CalendarCheck className="w-4 h-4 text-blue-400" />
                <span>{lang === 'ar' ? 'سجل اليوم' : 'Attendance Logs'}</span>
              </button>

              <button
                onClick={() => setActiveTab('employees')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activeTab === 'employees'
                    ? 'bg-[#0d2240] text-white font-bold border border-blue-900 shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80'
                }`}
              >
                <Users className="w-4 h-4 text-indigo-400" />
                <span>{lang === 'ar' ? 'الموظفين' : 'Employees'}</span>
              </button>

              <button
                onClick={() => setActiveTab('leaves')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap relative ${
                  activeTab === 'leaves'
                    ? 'bg-[#0d2240] text-white font-bold border border-blue-900 shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80'
                }`}
              >
                <UserCheck className="w-4 h-4 text-purple-400" />
                <span>{lang === 'ar' ? 'الإجازات' : 'Leaves'}</span>
                {pendingLeavesCount > 0 && (
                  <span className="bg-amber-500 text-slate-950 font-bold text-[10px] px-1.5 py-0.2 rounded-full font-mono">
                    {pendingLeavesCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('portal')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activeTab === 'portal'
                    ? 'bg-[#0d2240] text-white font-bold border border-blue-900 shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80'
                }`}
              >
                <User className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'ar' ? 'حساب الموظف' : 'Employee Portal'}</span>
              </button>

              <button
                onClick={() => setActiveTab('analytics')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activeTab === 'analytics'
                    ? 'bg-[#0d2240] text-white font-bold border border-blue-900 shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80'
                }`}
              >
                <BarChart3 className="w-4 h-4 text-amber-400" />
                <span>{lang === 'ar' ? 'التقارير' : 'Reports'}</span>
              </button>
            </>
          ) : (
            /* EMPLOYEE ONLY NAVIGATION */
            <button
              onClick={() => setActiveTab('portal')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                activeTab === 'portal'
                  ? 'bg-[#0d2240] text-white font-bold border border-blue-900 shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80'
              }`}
            >
              <User className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'ar' ? 'لوحة الموظف' : 'My Account Dashboard'}</span>
            </button>
          )}

        </div>
      </nav>

      {/* Avatar Modal for Logged-In User (Team Leader / Employee) */}
      {currentUser && (
        <AvatarModal
          isOpen={showAvatarModal}
          onClose={() => setShowAvatarModal(false)}
          employee={currentUser}
          onSaveAvatar={(newUrl) => {
            if (onUpdateEmployee) {
              onUpdateEmployee({
                ...currentUser,
                avatar: newUrl,
              });
            }
          }}
          lang={lang}
        />
      )}
    </header>
  );
};
