import React from 'react';

interface TechSourceLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
  className?: string;
}

export const TechSourceLogo: React.FC<TechSourceLogoProps> = ({
  size = 'md',
  showSubtitle = true,
  className = '',
}) => {
  const sizeClasses = {
    sm: {
      container: 'w-10 h-10 rounded-xl p-1',
      textMain: 'text-sm font-bold',
      textSub: 'text-[10px] font-medium tracking-wide',
      badge: 'text-[10px] px-1.5 py-0.2',
    },
    md: {
      container: 'w-14 h-14 rounded-2xl p-1.5 shadow-md',
      textMain: 'text-lg sm:text-xl font-extrabold tracking-tight',
      textSub: 'text-xs font-semibold tracking-wider',
      badge: 'text-xs px-2 py-0.5',
    },
    lg: {
      container: 'w-20 h-20 rounded-3xl p-2 shadow-xl',
      textMain: 'text-2xl sm:text-3xl font-black tracking-tight',
      textSub: 'text-xs sm:text-sm font-bold tracking-widest',
      badge: 'text-xs sm:text-sm px-2.5 py-0.5',
    },
  }[size];

  return (
    <div className={`flex items-center gap-3.5 ${className}`}>
      {/* Icon Frame - White Background */}
      <div className={`${sizeClasses.container} bg-white border border-slate-200 shadow-sm flex items-center justify-center relative overflow-hidden shrink-0 group`}>
        <img 
          src="/logo.png" 
          alt="TECH SOURCE" 
          referrerPolicy="no-referrer"
          className="w-full h-full object-contain rounded-lg transform group-hover:scale-105 transition duration-200"
          onError={(e) => {
            const target = e.currentTarget;
            target.style.display = 'none';
            if (target.nextElementSibling) {
              (target.nextElementSibling as HTMLElement).style.display = 'flex';
            }
          }}
        />
        {/* Fallback branded badge */}
        <div className="hidden w-full h-full rounded-md bg-[#0d2240] text-emerald-400 items-center justify-center font-black">
          <span className="text-white text-xs font-bold">TS</span>
        </div>
      </div>

      {/* Brand Typography */}
      <div className="flex flex-col items-start" dir="ltr">
        <div className={`flex items-center gap-2 ${sizeClasses.textMain} text-white`} dir="ltr">
          <span className="text-white font-black tracking-wide">TECH SOURCE</span>
          <span className={`${sizeClasses.badge} rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-mono font-bold`}>GDS</span>
        </div>
        {showSubtitle && (
          <span className={`${sizeClasses.textSub} text-slate-400 uppercase`} dir="ltr">
            GLOBAL DEVELOPMENT SOLUTIONS
          </span>
        )}
      </div>
    </div>
  );
};
