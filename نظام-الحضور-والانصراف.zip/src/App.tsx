import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { DashboardOverview } from './components/DashboardOverview';
import { KioskPunch } from './components/KioskPunch';
import { AttendanceLogTable } from './components/AttendanceLogTable';
import { EmployeeManager } from './components/EmployeeManager';
import { LeaveManager } from './components/LeaveManager';
import { AnalyticsView } from './components/AnalyticsView';
import { EmployeePortal } from './components/EmployeePortal';
import { DataImportModal } from './components/DataImportModal';
import { LoginModal } from './components/LoginModal';
import { CompanyRulesModal } from './components/CompanyRulesModal';
import { CompanySocialBar } from './components/CompanySocialBar';
import { 
  Employee, 
  Shift, 
  AttendanceRecord, 
  LeaveRequest, 
  Language, 
  LeaveStatus 
} from './types';
import { 
  INITIAL_EMPLOYEES, 
  INITIAL_SHIFTS, 
  INITIAL_ATTENDANCE, 
  INITIAL_LEAVES 
} from './mockData';
import { exportToCSV, evaluatePunch } from './utils/helpers';

export default function App() {
  const [lang, setLang] = useState<Language>('ar');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'kiosk' | 'attendance' | 'employees' | 'leaves' | 'analytics' | 'portal'>('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  // Current Logged-in User State (Always defaults to null so opening link starts on Login screen)
  const [currentUser, setCurrentUser] = useState<Employee | null>(() => {
    try {
      localStorage.removeItem('logged_in_user');
      sessionStorage.removeItem('logged_in_user');
    } catch {
      // ignore
    }
    return null;
  });

  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(true);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isRulesModalOpen, setIsRulesModalOpen] = useState(false);

  // Company Name Persistent State
  const [companyNameAr, setCompanyNameAr] = useState<string>(() => {
    return localStorage.getItem('company_name_ar') || 'شركة TECH SOURCE GDS';
  });
  const [companyNameEn, setCompanyNameEn] = useState<string>(() => {
    return localStorage.getItem('company_name_en') || 'TECH SOURCE - GDS Global';
  });

  // Persistent State
  const [employees, setEmployees] = useState<Employee[]>(() => {
    const validInitialCodes = new Set(INITIAL_EMPLOYEES.map(e => e.code));
    const saved = localStorage.getItem('attendance_employees');
    if (saved) {
      try {
        const parsed: Employee[] = JSON.parse(saved);
        // Only keep employees matching validInitialCodes or newly created ones
        const validOnly = parsed.filter(p => validInitialCodes.has(p.code));
        
        if (validOnly.length > 0) {
          const initMap = new Map(INITIAL_EMPLOYEES.map(e => [e.code, e]));
          const updated = validOnly.map(p => {
            const initEmp = initMap.get(p.code);
            if (initEmp) {
              return {
                ...p,
                nameAr: initEmp.nameAr,
                nameEn: initEmp.nameEn,
                jobTitleAr: initEmp.jobTitleAr,
                jobTitleEn: initEmp.jobTitleEn,
                role: initEmp.role,
                avatar: (p.avatar && p.avatar.length > 0) ? p.avatar : (initEmp.avatar || ''),
                annualLeaveBalance: p.annualLeaveBalance ?? initEmp.annualLeaveBalance ?? 15,
                casualLeaveBalance: p.casualLeaveBalance ?? initEmp.casualLeaveBalance ?? 7,
                regularLeaveBalance: p.regularLeaveBalance ?? initEmp.regularLeaveBalance ?? 8,
                sickLeaveBalance: p.sickLeaveBalance ?? initEmp.sickLeaveBalance ?? 30,
              };
            }
            return p;
          });

          const existingCodes = new Set(updated.map(e => e.code));
          const missing = INITIAL_EMPLOYEES.filter(e => !existingCodes.has(e.code));
          return [...updated, ...missing];
        }
      } catch {
        return INITIAL_EMPLOYEES;
      }
    }
    return INITIAL_EMPLOYEES;
  });

  const [shifts] = useState<Shift[]>(INITIAL_SHIFTS);

  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(() => {
    const saved = localStorage.getItem('attendance_records');
    return saved ? JSON.parse(saved) : INITIAL_ATTENDANCE;
  });

  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>(() => {
    const saved = localStorage.getItem('attendance_leaves');
    return saved ? JSON.parse(saved) : INITIAL_LEAVES;
  });

  // Keep state refs up to date to prevent closure staleness in pushSync and async operations
  const employeesRef = useRef(employees);
  const attendanceRecordsRef = useRef(attendanceRecords);
  const leaveRequestsRef = useRef(leaveRequests);
  const companyNameArRef = useRef(companyNameAr);
  const companyNameEnRef = useRef(companyNameEn);

  useEffect(() => { employeesRef.current = employees; }, [employees]);
  useEffect(() => { attendanceRecordsRef.current = attendanceRecords; }, [attendanceRecords]);
  useEffect(() => { leaveRequestsRef.current = leaveRequests; }, [leaveRequests]);
  useEffect(() => { companyNameArRef.current = companyNameAr; }, [companyNameAr]);
  useEffect(() => { companyNameEnRef.current = companyNameEn; }, [companyNameEn]);

  // Sync helper function to send state to Express backend server
  const pushSync = (overrides?: {
    employees?: Employee[];
    attendanceRecords?: AttendanceRecord[];
    leaveRequests?: LeaveRequest[];
    companyNameAr?: string;
    companyNameEn?: string;
  }) => {
    try {
      const payload = {
        employees: overrides?.employees ?? employeesRef.current,
        attendanceRecords: overrides?.attendanceRecords ?? attendanceRecordsRef.current,
        leaveRequests: overrides?.leaveRequests ?? leaveRequestsRef.current,
        companyNameAr: overrides?.companyNameAr ?? companyNameArRef.current,
        companyNameEn: overrides?.companyNameEn ?? companyNameEnRef.current,
      };
      fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }).catch(() => {});
    } catch {
      // Ignore network errors
    }
  };

  // Poll server every 2.5s to fetch live updates from other PCs/devices
  useEffect(() => {
    let isMounted = true;
    const fetchLatestData = async () => {
      try {
        const res = await fetch('/api/data');
        if (!res.ok) return;
        const data = await res.json();
        if (data.success && isMounted) {
          const validInitialCodes = new Set(INITIAL_EMPLOYEES.map(e => e.code));
          if (data.employees && Array.isArray(data.employees) && data.employees.length > 0) {
            const filteredEmployees = data.employees.filter((e: Employee) => validInitialCodes.has(e.code) || !e.code.startsWith('EMP'));
            const finalEmployees = filteredEmployees.length > 0 ? filteredEmployees : INITIAL_EMPLOYEES;
            setEmployees(finalEmployees);
            localStorage.setItem('attendance_employees', JSON.stringify(finalEmployees));
            setCurrentUser(prevUser => {
              if (!prevUser) return null;
              const match = finalEmployees.find((e: Employee) => e.id === prevUser.id);
              return match || prevUser;
            });
          } else {
            // Seed server if empty
            pushSync({ employees, attendanceRecords, leaveRequests, companyNameAr, companyNameEn });
          }

          if (data.attendanceRecords && Array.isArray(data.attendanceRecords)) {
            setAttendanceRecords(data.attendanceRecords);
            localStorage.setItem('attendance_records', JSON.stringify(data.attendanceRecords));
          }

          if (data.leaveRequests && Array.isArray(data.leaveRequests)) {
            setLeaveRequests(data.leaveRequests);
            localStorage.setItem('attendance_leaves', JSON.stringify(data.leaveRequests));
          }

          if (data.companyNameAr) {
            setCompanyNameAr(data.companyNameAr);
            localStorage.setItem('company_name_ar', data.companyNameAr);
          }

          if (data.companyNameEn) {
            setCompanyNameEn(data.companyNameEn);
            localStorage.setItem('company_name_en', data.companyNameEn);
          }
        }
      } catch {
        // network polling error ignored
      }
    };

    fetchLatestData();
    const interval = setInterval(fetchLatestData, 2500);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  // Clear any persistent auto-login localStorage so link always opens to Login Screen
  useEffect(() => {
    localStorage.removeItem('logged_in_user');
  }, []);

  useEffect(() => {
    localStorage.setItem('company_name_ar', companyNameAr);
  }, [companyNameAr]);

  useEffect(() => {
    localStorage.setItem('company_name_en', companyNameEn);
  }, [companyNameEn]);

  useEffect(() => {
    localStorage.setItem('attendance_employees', JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem('attendance_records', JSON.stringify(attendanceRecords));
  }, [attendanceRecords]);

  useEffect(() => {
    localStorage.setItem('attendance_leaves', JSON.stringify(leaveRequests));
  }, [leaveRequests]);

  // Handle Tab restrictions based on user role
  useEffect(() => {
    if (currentUser && currentUser.role === 'employee') {
      setActiveTab('portal');
    }
  }, [currentUser]);

  const handleLoginSuccess = (user: Employee) => {
    setCurrentUser(user);
    setIsLoginModalOpen(false);
    if (user.role === 'employee') {
      setActiveTab('portal');
    } else {
      setActiveTab('dashboard');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setIsLoginModalOpen(true);
  };

  const handleUpdateCompany = (nameAr: string, nameEn: string) => {
    setCompanyNameAr(nameAr);
    setCompanyNameEn(nameEn);
    pushSync({ companyNameAr: nameAr, companyNameEn: nameEn });
  };

  const handleImportEmployees = (newEmployees: Employee[], overwrite: boolean) => {
    let updatedList: Employee[] = [];
    if (overwrite) {
      updatedList = newEmployees;
    } else {
      const existingCodes = new Set(employees.map(e => e.code));
      const filteredNew = newEmployees.filter(e => !existingCodes.has(e.code));
      updatedList = [...employees, ...filteredNew];
    }
    setEmployees(updatedList);
    pushSync({ employees: updatedList });
  };

  const handleImportAttendance = (newRecords: AttendanceRecord[], overwrite: boolean) => {
    let updatedRecords: AttendanceRecord[] = [];
    if (overwrite) {
      updatedRecords = newRecords;
    } else {
      updatedRecords = [...attendanceRecords, ...newRecords];
    }
    setAttendanceRecords(updatedRecords);
    pushSync({ attendanceRecords: updatedRecords });
  };

  // Set RTL / LTR on html/body
  useEffect(() => {
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  // Handle Punch Event (Check in / Check out / Breaks / Force Leader Break Return)
  const handlePunch = (
    employeeId: string, 
    action: 'check_in' | 'check_out' | 'break_start' | 'break_end' | 'force_break_end',
    location: string,
    notes?: string
  ) => {
    const todayStr = new Date().toISOString().split('T')[0];
    const nowTimeStr = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const emp = employees.find(e => e.id === employeeId);
    if (!emp) return;

    // Rule: Block Check-In if employee has an approved leave registered by Team Leader for today
    if (action === 'check_in') {
      const activeApprovedLeave = leaveRequests.find(l => 
        l.employeeId === employeeId && 
        l.status === 'approved' && 
        todayStr >= l.startDate && 
        todayStr <= l.endDate
      );

      if (activeApprovedLeave) {
        const empName = lang === 'ar' ? emp.nameAr : emp.nameEn;
        alert(
          lang === 'ar'
            ? `عفواً، لا يمكن تسجيل الحضور اليوم! الموظف (${empName}) لديه إجازة معتمدة مسجلة من قِبل التيم ليدر للفترة من ${activeApprovedLeave.startDate} إلى ${activeApprovedLeave.endDate}.`
            : `Sorry, check-in disabled! Employee (${empName}) has an approved leave registered by the Team Leader from ${activeApprovedLeave.startDate} to ${activeApprovedLeave.endDate}.`
        );
        return;
      }
    }

    const shift = shifts.find(s => s.id === emp.shiftId) || shifts[0];

    let nextRecords: AttendanceRecord[] = [];

    setAttendanceRecords(prev => {
      const existingIndex = prev.findIndex(r => r.employeeId === employeeId && r.date === todayStr);

      if (existingIndex >= 0) {
        const existing = prev[existingIndex];
        const updated = { ...existing };

        if (action === 'check_in') {
          if (existing.checkIn) {
            alert(
              lang === 'ar'
                ? `عفواً، تم تسجيل الحضور بالفعل لهذا اليوم الساعة (${existing.checkIn})! التسجيل مسموح مرة واحدة فقط في اليوم.`
                : `Sorry, check-in has already been registered today at (${existing.checkIn})! Only 1 check-in allowed per day.`
            );
            return prev;
          }
          updated.checkIn = nowTimeStr;
        } else if (action === 'check_out') {
          if (existing.checkOut) {
            alert(
              lang === 'ar'
                ? `عفواً، تم تسجيل الانصراف بالفعل لهذا اليوم الساعة (${existing.checkOut})! التسجيل مسموح مرة واحدة فقط في اليوم.`
                : `Sorry, check-out has already been registered today at (${existing.checkOut})! Only 1 check-out allowed per day.`
            );
            return prev;
          }
          if (!existing.checkIn) {
            alert(
              lang === 'ar'
                ? `عفواً، يجب تسجيل الحضور أولاً قبل إمكانية تسجيل الانصراف!`
                : `Please check in first before checking out!`
            );
            return prev;
          }
          updated.checkOut = nowTimeStr;
        } else if (action === 'break_start') {
          updated.breakStart = nowTimeStr;
          updated.breakEnd = undefined;
          updated.notes = (updated.notes ? updated.notes + ' | ' : '') + 'بدأت الاستراحة: ' + nowTimeStr;
        } else if (action === 'break_end') {
          updated.breakEnd = nowTimeStr;
          updated.notes = (updated.notes ? updated.notes + ' | ' : '') + 'انتهت الاستراحة: ' + nowTimeStr;
        } else if (action === 'force_break_end') {
          updated.breakEnd = nowTimeStr;
          updated.notes = (updated.notes ? updated.notes + ' | ' : '') + 'تم إنهاء الاستراحة بواسطة التيم ليدر الساعة: ' + nowTimeStr;
        }

        if (notes) {
          updated.notes = (updated.notes ? updated.notes + ' - ' : '') + notes;
        }

        const todayApprovedPermission = leaveRequests.find(l => 
          l.employeeId === employeeId && 
          l.type === 'permission' && 
          l.status === 'approved' && 
          l.startDate === todayStr
        );
        const permSlot = todayApprovedPermission?.permissionSlot;

        const evaluated = evaluatePunch(updated.checkIn || nowTimeStr, updated.checkOut, shift, todayStr, permSlot);
        updated.lateMinutes = evaluated.lateMinutes;
        updated.lateSeconds = evaluated.lateSeconds;
        updated.earlyLeaveMinutes = evaluated.earlyLeaveMinutes;
        updated.workHours = evaluated.workHours;
        updated.overtimeHours = evaluated.overtimeHours;
        updated.status = evaluated.status;

        const newArr = [...prev];
        newArr[existingIndex] = updated;
        nextRecords = newArr;
        return newArr;
      } else {
        // Create new record for today
        const checkInVal = action === 'check_in' ? nowTimeStr : undefined;
        const checkOutVal = action === 'check_out' ? nowTimeStr : undefined;
        const breakStartVal = action === 'break_start' ? nowTimeStr : undefined;
        const breakEndVal = (action === 'break_end' || action === 'force_break_end') ? nowTimeStr : undefined;

        const todayApprovedPermission = leaveRequests.find(l => 
          l.employeeId === employeeId && 
          l.type === 'permission' && 
          l.status === 'approved' && 
          l.startDate === todayStr
        );
        const permSlot = todayApprovedPermission?.permissionSlot;

        const evaluated = evaluatePunch(checkInVal || nowTimeStr, checkOutVal, shift, todayStr, permSlot);

        const newRecord: AttendanceRecord = {
          id: `rec-${Date.now()}`,
          employeeId,
          date: todayStr,
          checkIn: checkInVal,
          checkOut: checkOutVal,
          breakStart: breakStartVal,
          breakEnd: breakEndVal,
          location,
          notes: action === 'force_break_end' ? 'تم إنهاء الاستراحة بواسطة التيم ليدر' : notes,
          lateMinutes: evaluated.lateMinutes,
          lateSeconds: evaluated.lateSeconds,
          earlyLeaveMinutes: evaluated.earlyLeaveMinutes,
          workHours: evaluated.workHours,
          overtimeHours: evaluated.overtimeHours,
          status: evaluated.status,
          verifiedByFace: true,
        };

        nextRecords = [newRecord, ...prev];
        return nextRecords;
      }
    });

    // Push synced attendance records to backend server
    setTimeout(() => {
      pushSync({ attendanceRecords: nextRecords.length > 0 ? nextRecords : undefined });
    }, 50);
  };

  // Add / Edit Record manually
  const handleAddRecord = (record: AttendanceRecord) => {
    setAttendanceRecords(prev => {
      const updated = [record, ...prev];
      pushSync({ attendanceRecords: updated });
      return updated;
    });
  };

  const handleUpdateRecord = (record: AttendanceRecord) => {
    setAttendanceRecords(prev => {
      const updated = prev.map(r => r.id === record.id ? record : r);
      pushSync({ attendanceRecords: updated });
      return updated;
    });
  };

  // Force end employee break by Leader
  const handleForceEndBreak = (empId: string) => {
    handlePunch(empId, 'force_break_end', '', 'إرجاع من الاستراحة بواسطة الليدر');
  };

  // Add Employee
  const handleAddEmployee = (emp: Employee) => {
    setEmployees(prev => {
      const updated = [...prev, emp];
      pushSync({ employees: updated });
      return updated;
    });
  };

  // Update Employee
  const handleUpdateEmployee = (updatedEmp: Employee) => {
    setEmployees(prev => {
      const updated = prev.map(e => e.id === updatedEmp.id ? updatedEmp : e);
      pushSync({ employees: updated });
      return updated;
    });
    // If updating currently logged in user, update currentUser as well
    if (currentUser && currentUser.id === updatedEmp.id) {
      setCurrentUser(updatedEmp);
    }
  };

  // Delete Employee
  const handleDeleteEmployee = (empId: string) => {
    const updated = employeesRef.current.filter(e => e.id !== empId);
    setEmployees(updated);
    employeesRef.current = updated;
    pushSync({ employees: updated });
  };

  // Leave Actions
  const handleAddLeave = (req: LeaveRequest) => {
    const nextLeaves = [req, ...leaveRequestsRef.current];
    setLeaveRequests(nextLeaves);
    leaveRequestsRef.current = nextLeaves;
    localStorage.setItem('attendance_leaves', JSON.stringify(nextLeaves));

    if (req.status === 'approved') {
      handleUpdateLeaveStatus(req.id, 'approved', req.reviewNotes || 'تم الاعتماد المباشر عند تقديم الطلب');
    } else {
      pushSync({ leaveRequests: nextLeaves });
    }
  };

  const handleUpdateLeaveStatus = (id: string, status: LeaveStatus, reviewNotes?: string) => {
    let updatedTargetReq: LeaveRequest | undefined;

    const currentLeaves = leaveRequestsRef.current;
    const nextLeaves = currentLeaves.map(l => {
      if (l.id === id) {
        updatedTargetReq = { ...l, status, reviewNotes };
        return updatedTargetReq;
      }
      return l;
    });

    if (!updatedTargetReq) return;

    setLeaveRequests(nextLeaves);
    leaveRequestsRef.current = nextLeaves;
    localStorage.setItem('attendance_leaves', JSON.stringify(nextLeaves));

    let nextEmployees = employeesRef.current;
    let nextAttendance = attendanceRecordsRef.current;

    if (status === 'approved' && updatedTargetReq) {
      const req = updatedTargetReq;
      if (req.type === 'annual' || req.type === 'casual' || req.type === 'regular' || req.type === 'emergency' || req.type === 'sick') {
        const start = new Date(req.startDate);
        const end = new Date(req.endDate);
        const diffTime = Math.max(0, end.getTime() - start.getTime());
        const days = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1);

        // 1. Deduct Leave Balances
        nextEmployees = employeesRef.current.map(emp => {
          if (emp.id === req.employeeId) {
            if (req.type === 'sick') {
              const sickBal = emp.sickLeaveBalance ?? 30;
              const newSick = Math.max(0, sickBal - days);
              return { ...emp, sickLeaveBalance: newSick };
            } else {
              const casual = emp.casualLeaveBalance ?? 7;
              const regular = emp.regularLeaveBalance ?? 8;
              const annual = emp.annualLeaveBalance ?? (casual + regular);

              if (req.type === 'casual' || req.type === 'emergency') {
                const newCasual = Math.max(0, casual - days);
                const newAnnual = Math.max(0, annual - days);
                return { ...emp, casualLeaveBalance: newCasual, annualLeaveBalance: newAnnual };
              } else {
                const newRegular = Math.max(0, regular - days);
                const newAnnual = Math.max(0, annual - days);
                return { ...emp, regularLeaveBalance: newRegular, annualLeaveBalance: newAnnual };
              }
            }
          }
          return emp;
        });

        // 2. Automatically generate on_leave AttendanceRecords
        const newRecords = [...attendanceRecordsRef.current];
        const cur = new Date(req.startDate);
        const endDateObj = new Date(req.endDate);

        while (cur <= endDateObj) {
          const dateStr = cur.toISOString().split('T')[0];
          const existingIdx = newRecords.findIndex(r => r.employeeId === req.employeeId && r.date === dateStr);
          const leaveRec: AttendanceRecord = {
            id: existingIdx >= 0 ? newRecords[existingIdx].id : `rec-leave-${req.employeeId}-${dateStr}`,
            employeeId: req.employeeId,
            date: dateStr,
            status: 'on_leave',
            workHours: 0,
            lateMinutes: 0,
            earlyLeaveMinutes: 0,
            overtimeHours: 0,
            notes: req.type === 'sick'
              ? `إجازة مرضية معتمدة: ${req.reason || 'تقرير طبي'}`
              : (req.reason ? `إجازة معتمدة: ${req.reason}` : 'إجازة رسمية معتمدة'),
            verifiedByFace: true,
          };

          if (existingIdx >= 0) {
            newRecords[existingIdx] = leaveRec;
          } else {
            newRecords.push(leaveRec);
          }

          cur.setDate(cur.getDate() + 1);
        }
        nextAttendance = newRecords;
      }
    }

    setEmployees(nextEmployees);
    employeesRef.current = nextEmployees;
    localStorage.setItem('attendance_employees', JSON.stringify(nextEmployees));

    setAttendanceRecords(nextAttendance);
    attendanceRecordsRef.current = nextAttendance;
    localStorage.setItem('attendance_records', JSON.stringify(nextAttendance));

    pushSync({
      leaveRequests: nextLeaves,
      employees: nextEmployees,
      attendanceRecords: nextAttendance
    });
  };

  // Export CSV helper
  const handleExportCSV = () => {
    exportToCSV(attendanceRecords, (id) => {
      const emp = employees.find(e => e.id === id);
      return emp ? emp.nameAr : id;
    });
  };

  const pendingLeavesCount = leaveRequests.filter(l => l.status === 'pending').length;

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 font-sans antialiased selection:bg-emerald-500 selection:text-white">
      {/* Top Main Navigation Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        lang={lang}
        setLang={setLang}
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        pendingLeavesCount={pendingLeavesCount}
        companyNameAr={companyNameAr}
        companyNameEn={companyNameEn}
        onOpenImportModal={() => setIsImportModalOpen(true)}
        onOpenRulesModal={() => setIsRulesModalOpen(true)}
        currentUser={currentUser}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onLogout={handleLogout}
        onUpdateEmployee={handleUpdateEmployee}
      />

      {/* Main Content Area */}
      <main className="py-6 pb-16">
        {activeTab === 'dashboard' && (
          <DashboardOverview
            employees={employees}
            attendanceRecords={attendanceRecords}
            leaveRequests={leaveRequests}
            onOpenManualPunch={() => setActiveTab('attendance')}
            onOpenAddEmployee={() => setActiveTab('employees')}
            onExportCSV={handleExportCSV}
            onUpdateLeaveStatus={handleUpdateLeaveStatus}
            setActiveTab={setActiveTab}
            lang={lang}
          />
        )}

        {activeTab === 'kiosk' && (
          <KioskPunch
            employees={employees}
            shifts={shifts}
            todayRecords={attendanceRecords.filter(r => r.date === new Date().toISOString().split('T')[0])}
            leaveRequests={leaveRequests}
            onPunch={handlePunch}
            onAddLeave={handleAddLeave}
            lang={lang}
            currentUser={currentUser}
          />
        )}

        {activeTab === 'attendance' && (
          <AttendanceLogTable
            records={attendanceRecords}
            employees={employees}
            shifts={shifts}
            onAddRecord={handleAddRecord}
            onUpdateRecord={handleUpdateRecord}
            onExportCSV={handleExportCSV}
            lang={lang}
            onForceEndBreak={handleForceEndBreak}
            currentUser={currentUser}
          />
        )}

        {activeTab === 'employees' && (
          <EmployeeManager
            employees={employees}
            shifts={shifts}
            attendanceRecords={attendanceRecords}
            leaveRequests={leaveRequests}
            onAddEmployee={handleAddEmployee}
            onUpdateEmployee={handleUpdateEmployee}
            onDeleteEmployee={handleDeleteEmployee}
            lang={lang}
            onOpenImportModal={() => setIsImportModalOpen(true)}
          />
        )}

        {activeTab === 'leaves' && (
          <LeaveManager
            leaveRequests={leaveRequests}
            employees={employees}
            onAddLeave={handleAddLeave}
            onUpdateLeaveStatus={handleUpdateLeaveStatus}
            lang={lang}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            records={attendanceRecords}
            employees={employees}
            leaveRequests={leaveRequests}
            lang={lang}
          />
        )}

        {activeTab === 'portal' && (
          <EmployeePortal
            employees={employees}
            attendanceRecords={attendanceRecords}
            leaveRequests={leaveRequests}
            onPunch={handlePunch}
            onAddLeave={handleAddLeave}
            onUpdateEmployee={handleUpdateEmployee}
            onAddRecord={handleAddRecord}
            onUpdateRecord={handleUpdateRecord}
            shifts={shifts}
            lang={lang}
            currentUser={currentUser}
          />
        )}
      </main>

      {/* Login Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        employees={employees}
        onLoginSuccess={handleLoginSuccess}
        lang={lang}
      />

      {/* Data & Company Import Modal */}
      <DataImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        companyNameAr={companyNameAr}
        companyNameEn={companyNameEn}
        onUpdateCompany={handleUpdateCompany}
        onImportEmployees={handleImportEmployees}
        onImportAttendance={handleImportAttendance}
        employeesCount={employees.length}
        lang={lang}
      />

      {/* Official Company Rules & Regulations Modal */}
      <CompanyRulesModal
        isOpen={isRulesModalOpen}
        onClose={() => setIsRulesModalOpen(false)}
        lang={lang}
      />

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-6 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 flex flex-col gap-5">
          {/* Official Social Links & Channels */}
          <CompanySocialBar lang={lang} variant="footer" />

          <div className="pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-right">
            <div className="flex items-center gap-2.5">
              <div className="w-6 h-6 rounded-md bg-white p-0.5 border border-slate-700 flex items-center justify-center shrink-0">
                <img 
                  src="/logo.png" 
                  alt="Logo" 
                  className="w-full h-full object-contain"
                  onError={(e) => { (e.currentTarget as HTMLElement).style.display = 'none'; }}
                />
              </div>
              <span className="font-medium text-slate-300">
                {lang === 'ar' ? `TECH SOURCE - GDS Global © 2026 - جميع الحقوق محفوظة` : `TECH SOURCE - GDS Global © 2026 - All Rights Reserved`}
              </span>
            </div>
            <div className="flex items-center gap-3 text-slate-400 font-mono text-[11px]">
              <span>by/Ahmed Mahmoud</span>
              <span>•</span>
              <span className="text-emerald-400 font-bold">{lang === 'ar' ? 'إصدار المؤسسات V2.5' : 'Enterprise V2.5'}</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
