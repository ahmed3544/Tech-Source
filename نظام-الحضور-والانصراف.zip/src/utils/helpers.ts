import { AttendanceRecord, Shift, AttendanceStatus, PermissionSlot } from '../types';

/**
 * Extract the first two names from a full name string (e.g. "Mostafa Mohamed" from "Mostafa Mohamed Kamel Abou Seada")
 */
export function getFirstTwoNames(fullName?: string): string {
  if (!fullName) return '';
  const parts = fullName.trim().split(/\s+/);
  if (parts.length <= 2) return fullName.trim();
  return `${parts[0]} ${parts[1]}`;
}

/**
 * Convert any Eastern Arabic numerals (٠١٢٣٤٥٦٧٨٩) to Western English numerals (0-9)
 */
export function toWesternDigits(val: string | number): string {
  if (val === undefined || val === null) return '';
  const str = String(val);
  return str.replace(/[٠-٩]/g, d => '0123456789'['٠١٢٣٤٥٦٧٨٩'.indexOf(d)]);
}

/**
 * Format date with Arabic names for days/months and Western numbers (0-9)
 */
export function formatDate(dateString: string, lang: 'ar' | 'en' = 'ar'): string {
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    
    // Get formatted string from locale
    const formatted = d.toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    
    return toWesternDigits(formatted);
  } catch {
    return toWesternDigits(dateString);
  }
}

/**
 * Format time to 12-Hour format with AM/PM using Western numbers (0-9)
 * Examples: "09:00:00 AM", "05:00:00 PM", "04:04:28 PM"
 */
export function formatTime(timeStr?: string | Date, lang: 'ar' | 'en' = 'ar'): string {
  if (!timeStr) return '--:--';
  
  if (timeStr instanceof Date) {
    const hours = timeStr.getHours();
    const minutes = String(timeStr.getMinutes()).padStart(2, '0');
    const seconds = String(timeStr.getSeconds()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const h12 = hours % 12 || 12;
    const hFormatted = String(h12).padStart(2, '0');
    return `${hFormatted}:${minutes}:${seconds} ${ampm}`;
  }

  const str = String(timeStr).trim();
  if (str.includes('AM') || str.includes('PM')) {
    return toWesternDigits(str);
  }

  const parts = str.split(':');
  if (parts.length < 2) return toWesternDigits(str);

  let hours = parseInt(parts[0], 10);
  const minutes = String(parts[1]).padStart(2, '0');
  const seconds = parts[2] ? String(parts[2]).padStart(2, '0') : '00';

  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12 || 12;
  const hFormatted = String(hours).padStart(2, '0');

  return `${hFormatted}:${minutes}:${seconds} ${ampm}`;
}

/**
 * Convert duration in seconds to HH:MM:SS format (Western digits)
 */
export function formatSecondsToHMS(totalSeconds: number): string {
  const secs = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = secs % 60;

  const hh = String(h).padStart(2, '0');
  const mm = String(m).padStart(2, '0');
  const ss = String(s).padStart(2, '0');

  return `${hh}:${mm}:${ss}`;
}

/**
 * Calculate late details when checking in after shift start:
 * - Default shift start 09:00 AM
 * - If approvedPermissionSlot is 'first_half' (نصف اليوم الأول), deadline is shifted by 2h to 11:00 AM.
 * - At or before deadline: On Time (0 late)
 * - After deadline: Late (متأخر)
 * - After 1 hour past deadline (> 60 mins late): Absent (غائب)
 */
export function calculateLateDetails(
  checkInTimeStr: string, 
  shiftStartStr: string = '09:00:00',
  permissionSlot?: PermissionSlot
): {
  isLate: boolean;
  isAbsent: boolean;
  lateMinutes: number;
  lateSeconds: number;
  formattedLateDuration: string;
} {
  const parseSeconds = (tStr: string) => {
    let str = tStr.trim();
    let isPM = false;
    let isAM = false;
    if (str.toUpperCase().includes('PM')) {
      isPM = true;
      str = str.replace(/PM/i, '').trim();
    } else if (str.toUpperCase().includes('AM')) {
      isAM = true;
      str = str.replace(/AM/i, '').trim();
    }
    
    const parts = str.split(':').map(Number);
    let h = parts[0] || 0;
    const m = parts[1] || 0;
    const s = parts[2] || 0;

    if (isPM && h < 12) h += 12;
    if (isAM && h === 12) h = 0;

    return h * 3600 + m * 60 + s;
  };

  const checkInSecs = parseSeconds(checkInTimeStr);
  let baseShiftSecs = parseSeconds(shiftStartStr); // 09:00:00 => 32400s

  // If approved permission is 'first_half' or general permission, shift arrival deadline to 11:00 AM (+2 hours)
  if (permissionSlot === 'first_half' || permissionSlot === 'custom') {
    baseShiftSecs += 2 * 3600; // Shift deadline to 11:00 AM
  }

  if (checkInSecs > baseShiftSecs) {
    const diffSecs = checkInSecs - baseShiftSecs;
    const lateMinutes = Math.floor(diffSecs / 60);
    const lateSeconds = diffSecs % 60;

    // Rule: More than 1 hour (3600 seconds) after deadline counts as Absent ("غائب")
    const isAbsent = diffSecs > 3600;
    const isLate = !isAbsent;

    return {
      isLate,
      isAbsent,
      lateMinutes,
      lateSeconds,
      formattedLateDuration: formatSecondsToHMS(diffSecs),
    };
  }

  return {
    isLate: false,
    isAbsent: false,
    lateMinutes: 0,
    lateSeconds: 0,
    formattedLateDuration: '00:00:00',
  };
}

/**
 * Calculate work hours for an attendance record dynamically
 */
export function calculateRecordWorkHours(r: Partial<AttendanceRecord>, shiftEndTime: string = '17:00:00'): number {
  if (r.workHours && r.workHours > 0) return r.workHours;
  if (!r.checkIn) return 0;
  
  const parseSecs = (str: string) => {
    let s = str.trim();
    let isPM = s.toUpperCase().includes('PM');
    let isAM = s.toUpperCase().includes('AM');
    s = s.replace(/AM|PM/gi, '').trim();
    const parts = s.split(':').map(Number);
    let h = parts[0] || 0;
    const m = parts[1] || 0;
    const sec = parts[2] || 0;
    if (isPM && h < 12) h += 12;
    if (isAM && h === 12) h = 0;
    return h * 3600 + m * 60 + sec;
  };

  const inSecs = parseSecs(r.checkIn);
  let outSecs: number;

  if (r.checkOut) {
    outSecs = parseSecs(r.checkOut);
  } else {
    const todayStr = new Date().toISOString().split('T')[0];
    if (r.date === todayStr || !r.date) {
      const now = new Date();
      const nowSecs = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
      outSecs = Math.max(inSecs, nowSecs);
    } else {
      outSecs = parseSecs(shiftEndTime);
    }
  }

  if (outSecs <= inSecs) return 0;
  const diffSecs = outSecs - inSecs;
  return Math.round((diffSecs / 3600) * 10) / 10;
}

/**
 * Evaluate attendance punch status with support for first_half and second_half permissions
 */
export function evaluatePunch(
  checkInTimeStr: string,
  checkOutTimeStr: string | undefined,
  shift: Shift,
  recordDate?: string,
  permissionSlot?: PermissionSlot
): {
  lateMinutes: number;
  lateSeconds: number;
  earlyLeaveMinutes: number;
  workHours: number;
  overtimeHours: number;
  status: AttendanceStatus;
} {
  const lateInfo = calculateLateDetails(checkInTimeStr, shift.startTime || '09:00:00', permissionSlot);
  
  let workHours = 0;
  let earlyLeaveMinutes = 0;
  let overtimeHours = 0;
  let status: AttendanceStatus = lateInfo.isAbsent ? 'absent' : lateInfo.isLate ? 'late' : 'on_time';

  const parseSecs = (str: string) => {
    let s = str.trim();
    let isPM = s.toUpperCase().includes('PM');
    let isAM = s.toUpperCase().includes('AM');
    s = s.replace(/AM|PM/gi, '').trim();
    const parts = s.split(':').map(Number);
    let h = parts[0] || 0;
    const m = parts[1] || 0;
    const sec = parts[2] || 0;
    if (isPM && h < 12) h += 12;
    if (isAM && h === 12) h = 0;
    return h * 3600 + m * 60 + sec;
  };

  const inSecs = parseSecs(checkInTimeStr);
  let shiftEndSecs = parseSecs(shift.endTime || '17:00:00');

  // If second_half permission, allow leaving at 3:00 PM (15:00) without early leave deduction
  if (permissionSlot === 'second_half') {
    shiftEndSecs -= 2 * 3600; // 15:00:00 (3:00 PM)
  }

  let outSecs: number | undefined = undefined;
  if (checkOutTimeStr) {
    outSecs = parseSecs(checkOutTimeStr);
  } else {
    const todayStr = new Date().toISOString().split('T')[0];
    if (recordDate === todayStr || !recordDate) {
      const now = new Date();
      const nowSecs = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
      outSecs = Math.max(inSecs, nowSecs);
    } else {
      outSecs = shiftEndSecs;
    }
  }

  if (outSecs !== undefined && outSecs > inSecs) {
    const durationSecs = outSecs - inSecs;
    workHours = Math.round((durationSecs / 3600) * 10) / 10;

    if (checkOutTimeStr) {
      if (lateInfo.isAbsent) {
        status = 'absent';
      } else if (outSecs < shiftEndSecs - 60) {
        earlyLeaveMinutes = Math.floor((shiftEndSecs - outSecs) / 60);
        status = 'early_leave';
      } else if (durationSecs > 8 * 3600 + 1800) {
        overtimeHours = Math.round(((durationSecs - 8 * 3600) / 3600) * 10) / 10;
        status = 'overtime';
      } else if (lateInfo.isLate) {
        status = 'late';
      } else {
        status = 'on_time';
      }
    } else {
      status = lateInfo.isAbsent ? 'absent' : lateInfo.isLate ? 'late' : 'in_progress';
    }
  } else {
    status = lateInfo.isAbsent ? 'absent' : lateInfo.isLate ? 'late' : 'in_progress';
  }

  return {
    lateMinutes: lateInfo.lateMinutes,
    lateSeconds: lateInfo.lateSeconds,
    earlyLeaveMinutes,
    workHours: Math.max(0, workHours),
    overtimeHours: Math.max(0, overtimeHours),
    status,
  };
}

export function getStatusText(status: AttendanceStatus, lang: 'ar' | 'en' = 'ar') {
  const mapAr: Record<AttendanceStatus, string> = {
    on_time: 'حاضر (في الوقت)',
    late: 'متأخر',
    early_leave: 'انصراف مبكر',
    overtime: 'ساعات إضافية',
    absent: 'غائب',
    on_leave: 'في إجازة',
    in_progress: 'قيد العمل الان',
  };

  const mapEn: Record<AttendanceStatus, string> = {
    on_time: 'On Time',
    late: 'Late Arrival',
    early_leave: 'Early Departure',
    overtime: 'Overtime Work',
    absent: 'Absent',
    on_leave: 'On Leave',
    in_progress: 'Currently Clocked In',
  };

  return lang === 'ar' ? mapAr[status] || status : mapEn[status] || status;
}

export function getStatusBadgeStyle(status: AttendanceStatus): string {
  switch (status) {
    case 'on_time':
      return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    case 'late':
      return 'bg-amber-50 text-amber-700 border-amber-200';
    case 'early_leave':
      return 'bg-orange-50 text-orange-700 border-orange-200';
    case 'overtime':
      return 'bg-purple-50 text-purple-700 border-purple-200';
    case 'absent':
      return 'bg-rose-50 text-rose-700 border-rose-200';
    case 'on_leave':
      return 'bg-sky-50 text-sky-700 border-sky-200';
    case 'in_progress':
      return 'bg-blue-50 text-blue-700 border-blue-200';
    default:
      return 'bg-slate-50 text-slate-700 border-slate-200';
  }
}

/**
 * Export attendance records or generic row objects to CSV file download
 */
export function exportToCSV(
  data: AttendanceRecord[] | Record<string, any>[], 
  getEmpNameOrFilename?: ((id: string) => string) | string,
  customFilename?: string
) {
  let csvContent = '\uFEFF';
  let fileName = customFilename || `attendance_report_${new Date().toISOString().split('T')[0]}.csv`;

  if (typeof getEmpNameOrFilename === 'string') {
    fileName = `${getEmpNameOrFilename}.csv`;
  }

  if (data.length === 0) return;

  const firstItem = data[0];

  // If passing formatted object array (e.g., Overall Search report)
  if (typeof firstItem === 'object' && !('employeeId' in firstItem)) {
    const headers = Object.keys(firstItem);
    const rows = (data as Record<string, any>[]).map(row => 
      headers.map(h => `"${String(row[h] ?? '').replace(/"/g, '""')}"`).join(',')
    );
    csvContent += [headers.join(','), ...rows].join('\n');
  } else {
    // Standard AttendanceRecord[]
    const getEmpName = typeof getEmpNameOrFilename === 'function' ? getEmpNameOrFilename : (id: string) => id;
    const records = data as AttendanceRecord[];
    const headers = ['تاريخ', 'الموظف', 'وقت الحضور', 'وقت الانصراف', 'ساعات العمل', 'ساعات إضافية', 'دقائق التأخير', 'الحالة'];
    
    const rows = records.map(r => [
      toWesternDigits(r.date),
      `"${getEmpName(r.employeeId)}"`,
      formatTime(r.checkIn),
      formatTime(r.checkOut),
      toWesternDigits(r.workHours?.toFixed(1) || '0'),
      toWesternDigits(r.overtimeHours?.toFixed(1) || '0'),
      toWesternDigits(r.lateMinutes || 0),
      getStatusText(r.status, 'ar')
    ]);

    csvContent += [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
  }

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', fileName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
