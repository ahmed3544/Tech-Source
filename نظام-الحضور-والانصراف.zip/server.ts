import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));

const DATA_FILE = path.join(process.cwd(), 'server_data.json');

// Helper to load stored data
function loadServerData() {
  if (fs.existsSync(DATA_FILE)) {
    try {
      const content = fs.readFileSync(DATA_FILE, 'utf-8');
      return JSON.parse(content);
    } catch (err) {
      console.error('Error reading server_data.json:', err);
    }
  }
  return null;
}

// Helper to save server data
function saveServerData(data: any) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing server_data.json:', err);
  }
}

// Global server state cache
let serverState: {
  employees?: any[];
  attendanceRecords?: any[];
  leaveRequests?: any[];
  companyNameAr?: string;
  companyNameEn?: string;
  lastUpdated?: number;
} = loadServerData() || {};

// API Routes

// GET /api/data - Fetch current central state for sync
app.get('/api/data', (req, res) => {
  const current = loadServerData();
  if (current) {
    serverState = current;
  }
  res.json({
    success: true,
    employees: serverState.employees || null,
    attendanceRecords: serverState.attendanceRecords || null,
    leaveRequests: serverState.leaveRequests || null,
    companyNameAr: serverState.companyNameAr || null,
    companyNameEn: serverState.companyNameEn || null,
    lastUpdated: serverState.lastUpdated || Date.now(),
  });
});

// POST /api/sync - Full or partial state update from client
app.post('/api/sync', (req, res) => {
  const { employees, attendanceRecords, leaveRequests, companyNameAr, companyNameEn } = req.body;
  
  if (employees !== undefined) serverState.employees = employees;
  if (attendanceRecords !== undefined) serverState.attendanceRecords = attendanceRecords;
  if (leaveRequests !== undefined) serverState.leaveRequests = leaveRequests;
  if (companyNameAr !== undefined) serverState.companyNameAr = companyNameAr;
  if (companyNameEn !== undefined) serverState.companyNameEn = companyNameEn;

  serverState.lastUpdated = Date.now();
  saveServerData(serverState);

  res.json({
    success: true,
    lastUpdated: serverState.lastUpdated,
    employees: serverState.employees,
    attendanceRecords: serverState.attendanceRecords,
    leaveRequests: serverState.leaveRequests,
    companyNameAr: serverState.companyNameAr,
    companyNameEn: serverState.companyNameEn,
  });
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', serverTime: new Date().toISOString() });
});

async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
